// CSS imports
import "../styles/styles.css";

import App from "./pages/app.js";

// Initialize app
const app = new App({
  content: document.getElementById("main-content"),
});

// Toggle navigation drawer on mobile
const drawerButton = document.getElementById("drawer-button");
const navigationDrawer = document.getElementById("navigation-drawer");

if (drawerButton && navigationDrawer) {
  drawerButton.addEventListener("click", () => {
    navigationDrawer.classList.toggle("active");
  });

  // Close drawer when link is clicked
  document.querySelectorAll(".nav-list a").forEach((link) => {
    link.addEventListener("click", () => {
      navigationDrawer.classList.remove("active");
    });
  });
}

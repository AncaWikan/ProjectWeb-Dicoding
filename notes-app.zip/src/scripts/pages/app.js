import UrlParser from "../routes/url-parser.js";
import routes from "../routes/routes.js";

class App {
  constructor({ content }) {
    this._content = content;
    this._initialAppShell();
  }

  _initialAppShell() {
    console.log("App initialized");

    // Initial render
    this._route();

    // Listen to hash change
    window.addEventListener("hashchange", () => {
      console.log("Hash changed");
      this._route();
    });
  }

  async _route() {
    const url = UrlParser.parseActiveUrlWithCombiner();
    console.log("Routing to:", url);

    const page = routes[url];

    if (!page) {
      console.error("Route not found:", url);
      window.location.hash = "#/";
      return;
    }

    console.log("Rendering page:", page.elementId);

    // Clear content
    this._content.innerHTML = "";

    // Add transition
    this._content.style.opacity = "0";
    this._content.style.transition = "opacity 0.3s ease-in-out";

    try {
      // Render page
      await page.render();

      // Get rendered element
      const pageElement = document.querySelector(page.elementId);

      if (pageElement) {
        // Move element dari main-content ke content (fix untuk double append)
        const existingInMain = this._content.querySelector(page.elementId);
        if (existingInMain) {
          this._content.innerHTML = "";
          this._content.appendChild(existingInMain);
        } else {
          // Element sudah di-append oleh page.render()
        }

        // Trigger fade-in animation
        setTimeout(() => {
          this._content.style.opacity = "1";
        }, 50);
      } else {
        console.warn(`Element ${page.elementId} not found after render`);
      }
    } catch (error) {
      console.error("Error rendering page:", error);
      this._content.innerHTML = `<div class="container"><p>Error: ${error.message}</p></div>`;
      this._content.style.opacity = "1";
    }
  }
}

export default App;

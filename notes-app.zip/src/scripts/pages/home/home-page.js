import api from "../../data/api.js";

const HomePage = {
  async render() {
    try {
      console.log("Rendering home page...");
      const res = await api.getAllStories(1, 30); // API bisa mengembalikan object atau array
      console.log("API getAllStories response:", res);

      // Normalisasi response ke array stories
      let stories = [];
      if (Array.isArray(res)) {
        stories = res;
      } else if (res && Array.isArray(res.listStory)) {
        stories = res.listStory;
      } else if (res && res.listStory && typeof res.listStory === "object") {
        // fallback: jika listStory adalah object, ambil values
        stories = Object.values(res.listStory);
      } else if (res && res.error) {
        this._showError(res.error);
        return;
      } else {
        // tidak ada data yang valid
        console.warn("getAllStories returned unexpected shape:", res);
        this._showError(
          "Data cerita tidak tersedia atau format tidak dikenali."
        );
        return;
      }

      this._displayStories(stories);
    } catch (error) {
      console.error("Error in HomePage.render:", error);
      this._showError(error.message || "Terjadi kesalahan saat memuat cerita");
    }
  },

  _displayStories(stories) {
    const homeContent = document.createElement("section");
    homeContent.id = "home-page";
    homeContent.className = "home-page";

    if (!Array.isArray(stories) || stories.length === 0) {
      homeContent.innerHTML = `
        <div class="container">
          <div class="stories-header">
            <h1>Daftar Cerita</h1>
            <a href="#/add-story" class="btn-add-story">+ Tambah Cerita</a>
          </div>
          <p>Tidak ada cerita tersedia. Coba refresh (F5). Jika baru saja menambah cerita, tunggu beberapa detik lalu refresh.</p>
        </div>
      `;
      document.getElementById("main-content").appendChild(homeContent);
      return;
    }

    // safe: stories pasti array di sini
    homeContent.innerHTML = `
      <div class="container">
        <div class="stories-header">
          <h1>Daftar Cerita</h1>
          <a href="#/add-story" class="btn-add-story">+ Tambah Cerita</a>
        </div>

        <div class="stories-container">
          <div id="map" class="map-container" style="height: 400px; margin-bottom: 2rem;"></div>
          
          <div id="stories-list" class="stories-list">
            ${stories
              .map(
                (story) => `
              <article class="story-card" data-lat="${
                story.lat || ""
              }" data-lon="${story.lon || ""}">
                <img src="${story.photoUrl || ""}" alt="Foto cerita ${
                  story.name || "pengguna"
                }" class="story-image" />
                <div class="story-content">
                  <h2>${story.name || "Tanpa Judul"}</h2>
                  <p class="story-description">${story.description || ""}</p>
                  <small>${
                    story.createdAt
                      ? new Date(story.createdAt).toLocaleDateString("id-ID")
                      : ""
                  }</small>
                </div>
              </article>
            `
              )
              .join("")}
          </div>
        </div>
      </div>
    `;

    document.getElementById("main-content").appendChild(homeContent);

    if (stories.length > 0) {
      setTimeout(() => {
        this._initMap(stories);
      }, 100);
    }
  },

  _initMap(stories) {
    const mapElement = document.getElementById("map");
    if (!mapElement) {
      console.error("Map element not found");
      return;
    }

    try {
      const map = L.map("map").setView([-6.2088, 106.8456], 10);

      L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
        attribution: "© OpenStreetMap contributors",
        maxZoom: 19,
      }).addTo(map);

      // buat map id->marker untuk sinkronisasi
      const markerById = new Map();

      stories.forEach((story) => {
        if (story.lat && story.lon) {
          const marker = L.marker([story.lat, story.lon]).addTo(map);
          marker.bindPopup(`
            <div class="marker-popup">
              <img src="${story.photoUrl || ""}" alt="${
            story.name || "Foto"
          }" style="width: 100%; height: auto; border-radius: 4px; max-height: 150px;" />
              <h3>${story.name || "Tanpa Judul"}</h3>
              <p>${(story.description || "").substring(0, 100)}...</p>
            </div>
          `);
          if (story.id) markerById.set(String(story.id), marker);
        }
      });

      // tambahkan click handler pada daftar cerita untuk pan ke marker
      document.querySelectorAll(".story-card").forEach((card) => {
        card.addEventListener("click", (e) => {
          const lat = parseFloat(card.dataset.lat);
          const lon = parseFloat(card.dataset.lon);
          const id = card.dataset.id || card.getAttribute("data-id"); // jika ada id
          if (!Number.isNaN(lat) && !Number.isNaN(lon)) {
            map.setView([lat, lon], 13, { animate: true });
            // buka popup jika marker tersedia
            if (id && markerById.has(String(id))) {
              markerById.get(String(id)).openPopup();
            } else {
              // fallback: buat marker sementara dan buka popup dari elemen card
              L.popup()
                .setLatLng([lat, lon])
                .setContent(card.querySelector(".story-content").innerHTML)
                .openOn(map);
            }
          }
        });
      });

      console.log("Map initialized with", stories.length, "markers");
    } catch (error) {
      console.error("Error initializing map:", error);
    }
  },

  _showError(message) {
    const homeContent = document.createElement("section");
    homeContent.id = "home-page";
    homeContent.className = "home-page";
    homeContent.innerHTML = `
      <div class="container">
        <div class="error-message">
          <p>⚠️ ${message}</p>
        </div>
      </div>
    `;
    document.getElementById("main-content").appendChild(homeContent);
  },

  elementId: "#home-page",
};

export default HomePage;

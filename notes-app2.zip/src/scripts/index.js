// CSS imports
import "../styles/styles.css";

import App from "./pages/app.js";

// Initialize app
const app = new App({
  content: document.getElementById("main-content"),
});

// NAV auth control helpers
function updateAuthNav() {
  const navLinks = document.querySelectorAll(".nav-list a");
  navLinks.forEach((a) => {
    const href = (a.getAttribute("href") || "").trim();
    if (href === "#/login" || href === "/#/login") {
      const token = localStorage.getItem("token");
      if (token) {
        a.textContent = "Logout";
        a.setAttribute("href", "#/");
        a.dataset.auth = "logout";
      } else {
        a.textContent = "Login";
        a.setAttribute("href", "#/login");
        delete a.dataset.auth;
      }
    }
  });
}

// delegated logout handler (document-level to capture dynamic nav changes)
document.addEventListener("click", (e) => {
  const logoutEl = e.target.closest('[data-auth="logout"]');
  if (!logoutEl) return;

  e.preventDefault();

  // perform logout
  localStorage.removeItem("token");
  localStorage.removeItem("userId");

  // update UI immediately
  updateAuthNav();

  // navigate to home (trigger routing)
  window.location.hash = "#/";

  // close drawer if open
  const navigationDrawer = document.getElementById("navigation-drawer");
  if (navigationDrawer) navigationDrawer.classList.remove("active");
});

// expose to pages (login page will call this after successful login)
window.updateAuthNav = updateAuthNav;

// initial state
updateAuthNav();

// Toggle navigation drawer on mobile
const drawerButton = document.getElementById("drawer-button");
const navigationDrawer = document.getElementById("navigation-drawer");

if (drawerButton && navigationDrawer) {
  drawerButton.addEventListener("click", () => {
    navigationDrawer.classList.toggle("active");
  });

  // Close drawer when link is clicked
  document.querySelectorAll(".nav-list a").forEach((link) => {
    link.addEventListener("click", () => {
      navigationDrawer.classList.remove("active");
    });
  });
}

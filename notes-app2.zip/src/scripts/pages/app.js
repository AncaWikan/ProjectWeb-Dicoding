import UrlParser from "../routes/url-parser.js";
import routes from "../routes/routes.js";

class App {
  constructor({ content }) {
    this._content = content;
    this._initialAppShell();
  }

  _initialAppShell() {
    // Initial render
    this._route();

    // Listen to hash change
    window.addEventListener("hashchange", () => {
      this._route();
    });
  }

  async _route() {
    const url = UrlParser.parseActiveUrlWithCombiner();
    const page = routes[url] || routes["/"];

    // prepare render function that clears container and runs page.render()
    const doRender = async () => {
      // always clear content to avoid duplicates
      this._content.innerHTML = "";

      // optional fade-out while rendering
      this._content.style.transition = "opacity 0.25s ease-in-out";
      this._content.style.opacity = "0";

      await page.render();

      // try to find the rendered element and ensure it's attached exactly once
      const pageElement = document.querySelector(page.elementId);
      if (pageElement) {
        // If it's already inside this._content, keep it; otherwise append
        if (!this._content.contains(pageElement)) {
          this._content.appendChild(pageElement);
        } else {
          // ensure it is the only child representation (move to end)
          this._content.appendChild(pageElement);
        }

        // fade-in
        setTimeout(() => {
          this._content.style.opacity = "1";
        }, 20);
      } else {
        // if page did not append element, show minimal placeholder
        console.warn(`Element ${page.elementId} not found after render`);
      }
    };

    try {
      if ("startViewTransition" in document) {
        await document.startViewTransition(async () => {
          await doRender();
        });
      } else {
        await doRender();
      }
    } catch (error) {
      console.error("Error during routing render:", error);
      this._content.innerHTML = `<div class="container"><p>Error: ${error.message}</p></div>`;
      this._content.style.opacity = "1";
    }
  }
}

export default App;
